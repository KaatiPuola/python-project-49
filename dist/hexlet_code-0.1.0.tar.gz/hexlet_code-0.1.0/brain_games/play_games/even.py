from random import randint
RULE = 'Answer "yes" if the number is even, otherwise answer "no".'

def game():
    question = randint(1, 100)
    if question % 2 == 0:
        right_answer = 'yes'
    elif question % 2 != 0:
        right_answer = 'no'
    return question, right_answer

