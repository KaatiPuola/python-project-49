#!/usr/bin/env python3

from brain_games.general import general
from brain_games.play_games import even

def main():
    general(even)

if __name__ == '__main__':
    main()
